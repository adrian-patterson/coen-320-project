#include <iostream>
#include <iomanip>
#include <thread>
#include <signal.h>
#include "Gear.h"
#include "EngineCoolantTemperature.h"
#include "EngineSpeed.h"
#include "FuelConsumption.h"
#include "VehicleSpeed.h"

using namespace std;

int current_time = 0;
int current_fuel_consumption_time = 0;
int current_engine_speed_time = 0;
int current_engine_coolant_temperature_time = 0;
int current_gear_time = 0;
int current_vehicle_speed_time = 0;

Gear gear;
EngineCoolantTemperature engine_coolant_temperature;
EngineSpeed engine_speed;
FuelConsumption fuel_consumption;
VehicleSpeed vehicle_speed;

thread create_timer(function<void(void)> func, unsigned int interval)
{
    return thread([func, interval]() {
        while (true)
        {
            func();
            this_thread::sleep_for(chrono::milliseconds(interval));
        }
    });
}


void print_state()
{
	cout << "Time: " << current_time
	        << setw(20) << "\tFuel Consumption: " << fuel_consumption.values[current_time]
	        << setw(20) << "\tEngine Speed: " << engine_speed.values[current_time]
	        << setw(20) << "\tEngine Coolant Temperature: " << engine_coolant_temperature.values[current_time]
	        << setw(20) << "\tGear: " << gear.values[current_time]
	        << setw(20) << "\tVehicle Speed: " << vehicle_speed.values[current_time] << endl;

   current_time++;
}


void user_keyboard_input()
{
	// interrupt and change values
}

int main()
{
    thread state_printer = create_timer(print_state, 100);
    state_printer.detach();
}
